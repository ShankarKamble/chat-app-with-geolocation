Dear Viewer,

This code is solely my proprietary and it is not connected with any company or organizations.

I request companies and organizations not use my link for yours work sample

Regards

Shankar Kamble

Using the MEAN stack, create a web page application that have following features.
1)Login / Registration pages.
2)Show the list of all users in a listview as well as on map view as pins (Geolocation of users).
3)User should be able to chat with one other user. 

