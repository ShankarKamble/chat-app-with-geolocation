module.exports = {
     db:"mongodb://localhost/meandemo",
    app: {
        name: "Mean Demo (Shankar Kamble)"
    }

}